#!/bin/bash

export CUDA_VISIBLE_DEVICES=0
export WANDB_DISABLED="false"
export WANDB_API_KEY=""
export HF_TOKEN=""

# Список learning rates для перебора
learning_rates=("6e-5" "7e-5" "8e-5" "9e-5" "4e-5" "3e-5" "2e-5" "1e-5")

for lr in "${learning_rates[@]}"; do
    command="python run.py"

    # Model and Task Configuration
    command+=" --model_name=\"roberta-large\""
    # command+=" --lora"
    command+=" --task_name=\"SST2\""
    command+=" --trainer=\"sparse_jaguar_muon\""

    # Logging and Reporting
    command+=" --output_dir=\"result/SST2-FT-lr${lr//./_}\""  # Заменяем точку на подчёркивание для корректного имени папки
    command+=" --report_to=\"wandb\""
    command+=" --project_name=\"zo-bench\""
    command+=" --logging_steps=10"

    # Training Configuration
    command+=" --num_train_epochs=5"
    command+=" --per_device_train_batch_size=16"
    command+=" --load_best_model_at_end"
    command+=" --evaluation_strategy=\"steps\""
    command+=" --save_strategy=\"steps\""
    command+=" --save_total_limit=1"
    command+=" --eval_steps=500"
    command+=" --max_steps=20000"
    command+=" --save_steps=1000"

    # Dataset Settings
    command+=" --num_eval=1000"
    command+=" --num_train=1000"
    command+=" --num_dev=500"
    command+=" --train_as_classification"
    command+=" --train_set_seed=0"

    # Training Hyperparameters
    command+=" --perturbation_mode=\"two_side\""
    command+=" --zo_eps=1e-3"
    command+=" --momentum=0.0"
    command+=" --weight_decay=0.0"
    command+=" --module_wise_perturbation=False"

    # Miscellaneous
    command+=" --overwrite_output_dir"

    # Learning Rate Scheduler Settings
    command+=" --learning_rate=$lr"
    command+=" --scheduler=\"cosine\""
    command+=" --num_training_steps=20000"
    command+=" --warmup_steps=0"
    command+=" --min_lr_ratio=0.1"
    command+=" --scheduler_cycle_length=1"

    # Sampling Methods
    command+=" --tensor_sampling_type=\"standard_normal\""
    command+=" --matrix_sampling_type=\"Random_baseline\""

    # Jaguar-Specific Parameters
    command+=" --zo_tau=1e-3"
    command+=" --zo_beta=0.9"
    # command+=" --zo_use_smoothing=true"

    # Sparse Jaguar-Specific Parameters
    command+=" --params_ratio=0.1"

    # Выполнение команды
    eval "$command"
done
